package com.example.raksha.game;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;

public class Animation {

    private Bitmap[] frames;
    private int frameIndex;
    private float frameTime;
    private long lastFrame;
    private boolean isPlaying = false;

    public boolean isPlaying() {
        return isPlaying;
    }
    public void play() {
        isPlaying = true;
        frameIndex = 0;
        lastFrame = System.currentTimeMillis();
    }
    public void stop() {
        isPlaying = false;

    }
    public Animation(Bitmap[] frames, float animeTime){

        this.frames = frames;
        frameIndex = 0;
        frameTime = animeTime/frames.length;
        lastFrame = System.currentTimeMillis();


    }

    public void update() {

        if (!isPlaying)
        {
            return;
            //if it's not playing then don't go to update method
        }
        if (System.currentTimeMillis() - lastFrame > frameTime*1000) {
            frameIndex++;   //GO TO NEXT FRAME
            frameIndex = frameIndex >= frames.length ? 0:frameIndex;   //if true then : else
            lastFrame = System.currentTimeMillis();
        }
    }

    public void draw(Canvas canvas, Rect destination) {
        if (!isPlaying) {
            return;
        }
        scaleRect(destination);
        canvas.drawBitmap(frames[frameIndex],null,destination, new Paint());
    }

    private void scaleRect(Rect rect) {
        float width_heightRatio = (float) (frames[frameIndex].getWidth())/frames[frameIndex].getHeight();
        if (rect.width()>rect.height())
            rect.left = rect.right - (int) (rect.height() * width_heightRatio);
        else
            rect.top = rect.bottom - (int) (rect.width() * (1/width_heightRatio));
    }


}
