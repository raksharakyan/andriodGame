package com.example.raksha.game;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

public class OrientationData implements SensorEventListener {

    private SensorManager manager;
    private Sensor accelerometer;
    private Sensor magnetometer;
    private float[] accelerometerOutput;
    private float[] magetometerOutput;
    private float[] orientation = new float[3];
    public float[] getOrientation() {

        return orientation;
    }
    private float[] startOrientation = null;
    public float[] getStartOrientation() {

        return startOrientation;
    }

    public void newGame() {
        startOrientation = null;
        //When we start a new game our phone might have some orientation,
        // we wanna take that as a reference and orient it accordingly.
    }

    public OrientationData() {
        manager = (SensorManager) Constants.CURRENT_CONTEXT.getSystemService(Context.SENSOR_SERVICE);
        accelerometer = manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        magnetometer = manager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);

    }

    public void register() {
        manager.registerListener(this,accelerometer,SensorManager.SENSOR_DELAY_GAME);
        manager.registerListener(this, magnetometer,SensorManager.SENSOR_DELAY_GAME);
    }
    public void pause() {
        manager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {

        if (sensorEvent.sensor.getType() == Sensor.TYPE_ACCELEROMETER)
            accelerometerOutput = sensorEvent.values;
        else if (sensorEvent.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD)
            magetometerOutput = sensorEvent.values;
        if (accelerometerOutput != null && magetometerOutput != null) {
            float[] R = new float[9]; //For 3x3 Rotation Matrix
            float[] I = new float[9]; //For 3x3 Inclination Matrix
            boolean success = SensorManager.getRotationMatrix(R,I,accelerometerOutput,magetometerOutput);
            if (success) {
                SensorManager.getOrientation(R, orientation);
                if (startOrientation == null) {
                    startOrientation = new float[orientation.length];
                    System.arraycopy(orientation,0, startOrientation,0, orientation.length);
                }
            }

        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
}
