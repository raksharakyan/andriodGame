package com.example.raksha.game;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;

public class RectPlayer implements GameObject {
    private Rect rectangle;   //rect stores info for rectangle
    int color; //colors are represented by int in Android studio
    private Animation idle;
    private Animation walkRight;
    private Animation walkLeft;
    private AnimationManager animationManager;

    public RectPlayer(Rect rectangle, int color) {
        this.rectangle = rectangle;
        this.color = color;
        BitmapFactory bitmapFactory = new BitmapFactory();
        Bitmap idleImage = bitmapFactory.decodeResource(Constants.CURRENT_CONTEXT.getResources(),R.drawable.alienblue_idle);
        Bitmap walk1 = bitmapFactory.decodeResource(Constants.CURRENT_CONTEXT.getResources(),R.drawable.alienblue_walk1);
        Bitmap walk2 = bitmapFactory.decodeResource(Constants.CURRENT_CONTEXT.getResources(),R.drawable.alienblue_walk2);
        Bitmap walk3 = bitmapFactory.decodeResource(Constants.CURRENT_CONTEXT.getResources(),R.drawable.alienblue_walk3);
        Bitmap walk4 = bitmapFactory.decodeResource(Constants.CURRENT_CONTEXT.getResources(),R.drawable.alienblue_walk4);

        idle = new Animation(new Bitmap[]{idleImage},2);
        walkRight = new Animation(new Bitmap[]{walk1,walk2}, 0.5f);
        walkLeft = new Animation(new Bitmap[]{walk3,walk4}, 0.5f);
        animationManager = new AnimationManager(new Animation[] {idle, walkRight, walkLeft});

    }
    public Rect getRectangle() {
        return rectangle;
    }

    @Override
    public void draw(Canvas canvas) {
        /*Paint paint = new Paint();
        paint.setColor(color);
        canvas.drawRect(rectangle,paint); */
        animationManager.draw(canvas,rectangle);

    }

    @Override
    public void update() {

        animationManager.update();

    }

    public void update(Point point) {

        float oldLeft = rectangle.left;

        //left,top,right,bottom
        rectangle.set(point.x - rectangle.width()/2, point.y - rectangle.height()/2,point.x + rectangle.width()/2, point.y + rectangle.height()/2);
        /* 1. Sets left,top,right,bottom to center because we did /2 for all.
           2. If we move our finger down the screen , the Y value increases.
         */
        //State 0 for idle, state 1 for right, state 2 for left
        //if player moves atleast 5 pixels direction change
        int state =0;
        if (rectangle.left - oldLeft > 3){
            state = 1;
        }
        else if (rectangle.left - oldLeft < -3) {
            state = 2;
        }
        animationManager.playAnime(state);
        animationManager.update();

    }
}
