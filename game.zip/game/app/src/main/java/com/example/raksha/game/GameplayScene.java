package com.example.raksha.game;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.hardware.SensorEvent;
import android.view.MotionEvent;

public class GameplayScene implements Scene {

    private RectPlayer player;
    private Rect r = new Rect();
    private Point playerPoint;
    private ObstacleManager obstacleManager;
    private boolean movingPlayer = false;
    private boolean gameOver = false;
    private long gameOverTime;
    private OrientationData orientationData;
    private long frameTime;

    public GameplayScene() {


        player =  new RectPlayer(new Rect(100,100,200,200), Color.rgb(77,0,200));
        playerPoint = new Point(Constants.SCREEN_WIDTH/2, (3*Constants.SCREEN_HEIGHT)/4); //middle of screen and 3/4th height of screen
        player.update(playerPoint);
        obstacleManager = new ObstacleManager(300, 350, 75, Color.GRAY);
        orientationData = new OrientationData();
        orientationData.register();
        frameTime = System.currentTimeMillis();
    }

    public void reset () {

        //reset all
        playerPoint = new Point(Constants.SCREEN_WIDTH/2, (3*Constants.SCREEN_HEIGHT)/4); //middle of screen and 3/4th height of screen
        player.update(playerPoint);
        obstacleManager = new ObstacleManager(300, 350, 75, Color.GRAY);
        movingPlayer =  false;

    }

    @Override
    public void update() {

        if (!gameOver) {
            if (frameTime < Constants.INIT_TIME)
                frameTime = Constants.INIT_TIME;
            int elapsedTime = (int) (System.currentTimeMillis() - frameTime);
            frameTime = System.currentTimeMillis();
            if (orientationData.getOrientation() != null && orientationData.getStartOrientation() != null) {
                float pitch = orientationData.getOrientation()[1] - orientationData.getStartOrientation()[1];
                float roll = orientationData.getOrientation()[2] - orientationData.getStartOrientation()[2];
                float xSpeed = 2*roll*Constants.SCREEN_WIDTH/1000f;
                float ySpeed = pitch*Constants.SCREEN_HEIGHT/1000f;
                playerPoint.x += Math.abs(xSpeed*elapsedTime) > 5 ? xSpeed*elapsedTime : 0;
                playerPoint.y -= Math.abs(ySpeed*elapsedTime) > 5 ? ySpeed*elapsedTime : 0;
            }

            //BOUNDING
            if (playerPoint.x < 0)
                playerPoint.x = 0;
            else if (playerPoint.x > Constants.SCREEN_WIDTH)
                playerPoint.x = Constants.SCREEN_WIDTH;
            if (playerPoint.y < 0)
                playerPoint.y = 0;
            else if (playerPoint.y > Constants.SCREEN_HEIGHT)
                playerPoint.y = Constants.SCREEN_HEIGHT;

            //The above statements are bounding the player char to the screen so wee don't go off screen

            player.update(playerPoint);
            obstacleManager.update();
            if (obstacleManager.playerCollide(player)) {
                gameOver =  true;
                gameOverTime = System.currentTimeMillis();
            }
        }

    }

    @Override
    public void draw(Canvas canvas) {

        canvas.drawColor(Color.BLACK);
        obstacleManager.draw(canvas);
        player.draw(canvas);

        if (gameOver) {
            Paint paint =  new Paint();
            paint.setTextSize(100);
            paint.setColor(Color.WHITE);
            drawCenterText(canvas,paint,"GAME OVER");

        }

    }
    //For a display message at game over
    private void drawCenterText(Canvas canvas, Paint paint, String text) {
        canvas.getClipBounds(r);
        int cHeight = r.height();
        int cWidth = r.width();
        paint.setTextAlign(Paint.Align.LEFT);
        paint.getTextBounds(text, 0, text.length(), r);
        float x = cWidth / 2f - r.width() / 2f - r.left;
        float y = cHeight / 2f + r.height() / 2f - r.bottom;
        canvas.drawText(text, x, y, paint);
    }

    @Override
    public void recieveTouch(MotionEvent event) {

        switch (event.getAction()) {

            case MotionEvent.ACTION_DOWN:
                if (!gameOver && player.getRectangle().contains((int) event.getX(),(int )event.getY()))
                {
                    movingPlayer = true;
                }

                //after game over is shown , if we wait 2 seconds the game restarts
                if (gameOver && System.currentTimeMillis() - gameOverTime >= 2000) {
                    reset();
                    gameOver =false;
                    orientationData.newGame();
                }
                break;
            case MotionEvent.ACTION_MOVE:
                if (!gameOver && movingPlayer)
                {
                    playerPoint.set((int)event.getX(),(int)event.getY()); //These methods require float so we typecast
                }
                break;
            case MotionEvent.ACTION_UP:
                movingPlayer = false;
                break;



        }


    }

    @Override
    public void terminate() {

        SceneManager.ACTIVE_SCENE =0;

    }

}
