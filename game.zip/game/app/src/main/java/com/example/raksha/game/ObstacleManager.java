package com.example.raksha.game;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

import java.util.ArrayList;
import java.util.PriorityQueue;


//Higher index = lower on screen = higher Y value

public class ObstacleManager {

    private ArrayList<Obstacle> obstacles;
    private int playerGap;
    private int obstacleGap;
    private int obstacleHeight;
    private int color;
    private long startTime;
    private long initTime;
    private int score = 0;

    public ObstacleManager(int playerGap, int obstacleGap, int obstacleHeight, int color) {
        this.playerGap = playerGap;
        this.obstacleGap = obstacleGap;
        this.obstacleHeight = obstacleHeight;
        this.color = color;
        startTime = initTime = System.currentTimeMillis();   //Gets System time in milliseconds
        obstacles = new ArrayList<>();
        createObstacles();
    }




    private void createObstacles(){

        int currentY; //in obstacle.java it is the startY
        currentY = -5*(Constants.SCREEN_HEIGHT)/4;  // 5/4th of screen height

        // obstacles.size() - 1 will get last index
        // getRectangle().bottom<0 gives bottom value rectangle, if its less than 0 then do...

        while (currentY<0) {

            //subtract playerGap coz the random obstacle can take up the whole screen
            int startX = (int) (Math.random()*(Constants.SCREEN_WIDTH) - playerGap);

            //args are (rectHeight, color, startX, startY, playerGap)
            obstacles.add(new Obstacle(obstacleHeight, color, startX, currentY, playerGap));
            currentY += obstacleHeight + obstacleGap ;    //avoid overlapping


        }

    }


    public boolean playerCollide(RectPlayer player) {

        for(Obstacle ob : obstacles) {
            if (ob.playerCollide(player)) {

                return true;

            }
        }

        return false;

    }

    public void update(){

        if (startTime < Constants.INIT_TIME) {
            startTime = Constants.INIT_TIME;
        }
        int elapsedTime = (int) (System.currentTimeMillis() - startTime);
        startTime = System.currentTimeMillis();

        //to increase speed over time during game
        float speed = (float)(Math.sqrt(1+(startTime - initTime)/2000.0))*Constants.SCREEN_HEIGHT/(10000.0f);   //10000 coz time is in nano second, .0f for float
        for (Obstacle ob : obstacles) {
            ob.incrementY(speed*elapsedTime);

        }
        if (obstacles.get(obstacles.size() - 1).getRectangle().top >= Constants.SCREEN_HEIGHT) {
            int xStart = (int) (Math.random()*(Constants.SCREEN_WIDTH - playerGap));
            obstacles.add(0, new Obstacle(obstacleHeight,color,xStart,
                    obstacles.get(0).getRectangle().top - obstacleHeight - obstacleGap,playerGap));

            //remove previous obstacles so they don't overlap
           obstacles.remove(obstacles.size()-1);
           score++;



        }



    }


    public void draw(Canvas canvas){

        for (Obstacle ob : obstacles) {
            ob.draw(canvas);

        }
        Paint paint = new Paint();
        paint.setTextSize(30);
        paint.setColor(Color.WHITE);
        canvas.drawText("SCORE "+score,50,50 + paint.descent() - paint.ascent(),paint);

    }
}

